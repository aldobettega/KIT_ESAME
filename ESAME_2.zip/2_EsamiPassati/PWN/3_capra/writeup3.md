In this simple pwnable, we're given a 4-byte Write-What-Where in a position dependent executable with partial RELRO.

A simple idea would be to overwrite one of the GOT entries of the binary, which are writeable as it's not compiled with Full RELRO. 

A thing to note is that we only have a 4-byte write, thus we can't target the whole entry (8 bytes since we're on x86-64) so we must target a GOT entry which hasn't been initialized yet.

After the write only two functions get called: puts and exit. Overwriting puts will lead to a segmentation fault as the entry will become 2 bytes of a libc address followed by our value.

Overwriting exit, instead, will allow us to call a function inside the binary (which is based at 0x400000, thus functions' addresses fit in 4 bytes).

The exit function is called with rdi = 1 and we can't control that, so we need a function that either works with rdi = 1 or that completely ignores arguments.

Luckily the binary provides a print_flag function which will happly print the flag regardless of arguments, so we can just overwrite the GOT entry of exit (0x601060) to print_flag (0x400807)

FLAG: spritz{c4pr4_c4pr4_c4pr4!!}