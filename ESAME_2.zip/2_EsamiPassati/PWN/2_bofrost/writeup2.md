In this simple pwnable we're given a position-independent executable compiled with Full RELRO and execstack.

There is a obvious stack buffer overflow due to the use of the unsafe "gets" function.

We are also given a leak of the stack, so that we know where the overflown buffer is.

To spawn a shell we can insert our shellcode into the buffer, pad to 256 bytes to reach the saved rbp, pad another 8 bytes to reach the return address, and finally put the address of our buffer (which is the leak + 0x10). 

When the main function returns, the control flow jumps to the stack, thus executing our shellcode.

The provided script spawns a shell, typing `cat flag` will easily lead to the flag.

FLAG: spritz{BoFrosting_outs1d3_th3s3_days}