input = "passwd"
	
for c in input:
    print(chr ((ord(c)-94)%26+97) )
