RULES = you cannot access to 'web' and 'other' folders.

How to run:

Open a terminal, navigate to this directory using `cd`, and run `docker compose up -d`.
The website will be available at http://127.0.0.1:8084 .
When you are finished, remember to run `docker compose down`.
