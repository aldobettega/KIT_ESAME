import base64
import string
import binascii

ALPHABET = list(string.printable)  
LEN = len(ALPHABET)

with open('encrypted_flag.txt', 'r') as f:
    encrypted_message=f.read()

def ROT_13(msg):
    risultato = ""
    for c in msg:
        indice = ALPHABET.index(c)
        risultato += ALPHABET[(indice-13)%LEN]
    return risultato

x = ROT_13(encrypted_message)
print(x)