import string

with open("ciphertext.txt", "r") as f:
    ZO_text = f.read()
    f.close()

def ZO_to_01(msg):
    for c in msg:
        msg = msg.replace("Z", "0")
        msg = msg.replace("O", "1")
    return msg


binary = ZO_to_01(ZO_text)
#text = binary_to_ascii(binary)
print(binary)
