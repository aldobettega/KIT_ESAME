import base64
import string
import binascii

ALPHABET = list(string.printable)   # len = 100
LEN = len(ALPHABET)

def base64_to_ascii(base64_str):
    # Decodifica la stringa Base64 in bytes
    decoded_bytes = base64.b64decode(base64_str)
    # Decodifica i bytes in una stringa ASCII
    ascii_str = decoded_bytes.decode('ascii')
    return ascii_str

def base32_to_ascii(base32_str):
    # Decodifica la stringa Base32 in bytes
    decoded_bytes = base64.b32decode(base32_str)
    # Decodifica i bytes in una stringa ASCII
    ascii_str = decoded_bytes.decode('ascii')
    return ascii_str

def XORencode(message, KEY="c4mPar1"):
    rep = len(message)//len(KEY) + 1
    key = (KEY*rep)[:len(message)]  # adjust the key length
    xored = ''.join([chr(ord(a) ^ ord(b)) for a, b in zip(message, key)])
    return xored

def ROTencode(message, pos):
    rot13_enc = ''
    for c in message:
        if c in ALPHABET:
            i = ALPHABET.index(c)
            rot13_enc += ALPHABET[(i + pos) % LEN]
        else:
            # If the character is not in ALPHABET, just append it as is
            rot13_enc += c
    return rot13_enc

def hex_to_ascii(hex_str):
    # Converte la stringa esadecimale in byte
    bytes_obj = bytes.fromhex(hex_str)
    # Decodifica i byte in una stringa ASCII
    ascii_str = bytes_obj.decode('ascii')
    return ascii_str

with open("encrypted_flag.txt", "r") as f:
    hex_encrypted = f.read()

xor_encrypted = hex_to_ascii(hex_encrypted)

# Ensure XORed string is properly decoded to ASCII
encrypted = XORencode(xor_encrypted).encode('ascii')

for _ in range(15):
    # ROTencode works with printable characters
    b32_encrypted = ROTencode(encrypted, -3)  # Decode encrypted before passing it to ROTencode
    rot13_encrypted = base32_to_ascii(b32_encrypted)
    b64_encrypted = ROTencode(rot13_encrypted, -13)
    encrypted = base64_to_ascii(b64_encrypted)

print(encrypted)
