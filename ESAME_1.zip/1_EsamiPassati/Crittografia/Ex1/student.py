import random

flag_cipher = "ye}GTE{tkspu~1"

def enc(x):
    x = x[-2:] + x[:-2]
    x = ''.join([chr(ord(c) + (i % 3))for i, c in enumerate(x)])
    x = ''.join([x[len(x) - i - 1] for i in range(len(x))])
    return x
    
    
##############SOLUZIONE##############
"""
cripta:
1. porta gli ultimi due elementi della lista in testa, il resto shifta in avanti di due
2. shifta caratteri di +0,+1,+2 in modo ciclico
3. rovescia il messaggio

decrypt:
1.ri-rovesciare il messaggio
2.shifta caratteri di -2,-1,-0 in modo ciclico
3.portare i primi due elementi in coda alla lista, shiftare il resto indietro di due
"""

def dec(x):
    x = ''.join([x[len(x) - i - 1] for i in range(len(x))])
    x = ''.join([chr(ord(c) - (i % 3))for i, c in enumerate(x)])
    x = x[2:] + x[:2]
    return x
    

print(dec(flag_cipher))

    
